/* config.h.  Generated automatically by configure.  */
/* Process this file with configure to produce config.h. -*- mode: c -*- */
#ifndef SAMPLEPACKAGE_CONFIG_H
#define SAMPLEPACKAGE_CONFIG_H

/* `samplepackage' doesn't need any extra configuration. */

#endif /* SAMPLEPACKAGE_CONFIG_H */
